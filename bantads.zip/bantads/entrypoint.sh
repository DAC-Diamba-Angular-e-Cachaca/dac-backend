#!/bin/bash

npm install
eval '$@'