export class City {
  constructor(
    public id?: number,
    public nome?: string,
    public estado?: number
  ) {}
}
