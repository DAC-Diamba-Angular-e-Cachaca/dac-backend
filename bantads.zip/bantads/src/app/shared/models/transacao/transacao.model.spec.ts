import { Transacao } from './transacao.model';

describe('Transacao', () => {
  it('should create an instance', () => {
    expect(new Transacao()).toBeTruthy();
  });
});
