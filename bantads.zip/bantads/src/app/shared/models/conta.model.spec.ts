import { Conta } from './conta.model';

describe('Conta', () => {
  it('should create an instance', () => {
    expect(new Conta()).toBeTruthy();
  });
});
