import { CpfValidatorDirective } from './cpf-validator.directive';

describe('CpfValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new CpfValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
