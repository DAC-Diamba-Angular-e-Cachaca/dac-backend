export * from './app-routing-gerente.module';
export * from './gerente-home';
export * from './gerente.module';
