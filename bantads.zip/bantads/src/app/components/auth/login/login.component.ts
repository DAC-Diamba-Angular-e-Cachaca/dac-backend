import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ClienteService } from '@components/cliente/services/cliente.service';
import { Conta } from '@shared/models/conta.model';
import { Login } from '@shared/models/login.model';
import { UserService } from '../services/user.service';
import { User } from './../../../shared/models/user.model';
import { AuthService } from './../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  @ViewChild('formLogin') formLogin!: NgForm;
  login: Login = new Login();
  loading: boolean = false;
  message!: string;

  constructor(
    private authService: AuthService,
    private userService: UserService,
    private clienteService: ClienteService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    
    if (this.authService.usuarioLogado)
   

      this.router.navigate([
        '/' +
          (this.authService.usuarioLogado.cargo?.toLocaleLowerCase() === 'administrador'
            ? 'admin'
            : this.authService.usuarioLogado.cargo?.toLocaleLowerCase() === 'gerente'
            ? 'gerente'
            : 'cliente') +
          '/home',
      ]);
  }

  ngOnInit(): void {
    this.route.queryParams.subscribe(
      (params: any) => (this.message = params['error'])
    );
  }

  logar() {
    this.loading = true;
    if (this.formLogin.form.valid) {
      this.authService
        .login(this.login)
        .subscribe((response: any) => {
          const usuario:User = response.data;
          usuario.id = response.data._id;
          const token:String = response.token;
          if (usuario) {
            this.authService.usuarioLogado = usuario;
            this.authService.token = token;
            if (usuario.cargo?.toLocaleLowerCase() == 'cliente') {
              
              this.clienteService
                .buscarContaPorUserId(usuario.id!)
                .subscribe((contas: Conta[]) => {
                  this.authService.contaCliente = contas[0];
                  this.router.navigate([
                    '/' +
                      (this.authService.usuarioLogado.cargo?.toLocaleLowerCase() === 'administrador'
                        ? 'admin'
                        : this.authService.usuarioLogado.cargo?.toLocaleLowerCase() === 'gerente'
                        ? 'gerente'
                        : 'cliente') +
                      '/home',
                  ]);
                });
            } else {
             
              console.log('Usuario Logado:',usuario);
              //window.alert(JSON.stringify(usuario))
              this.router.navigate([
                '/' +
                  (this.authService.usuarioLogado.cargo?.toLocaleLowerCase() === 'administrador'
                    ? 'admin'
                    : this.authService.usuarioLogado.cargo?.toLocaleLowerCase() === 'gerente'
                    ? 'gerente'
                    : 'cliente') +
                  '/home',
              ]);
            }
          } else {
            this.message = 'Usuário/Senha inválidos.';
          }
        });
    }
    this.loading = false;
  }
}
