import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@environment/environment';
import { Transacao } from '@shared/models';
import { Conta } from '@shared/models/conta.model';
import { Observable } from 'rxjs';
const LS_USER: string = 'user';
const LS_CONTA: string = 'conta';
const LS_TOKEN: string = 'token';
@Injectable({
  providedIn: 'root',
})
export class ClienteService {
  private apiUrlConta = environment.url.conta;
  private apiUrlTransacaos = environment.url.transacaos;

  constructor(private http: HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'x-access-token': localStorage[LS_TOKEN] ? localStorage[LS_TOKEN]: null 
    }),
  };

  inserir(conta: Conta): Observable<Conta> {
    return this.http.post<Conta>(
      this.apiUrlConta,
      JSON.stringify(conta),
      this.httpOptions
    );
  }

  getAll(): Observable<Conta[]> {
    return this.http.get<Conta[]>(this.apiUrlConta + '/list');
  }

  getAllTransacaos(): Observable<Transacao[]> {
    return this.http.get<Transacao[]>(this.apiUrlTransacaos);
  }

  postTransacao(transacao: Transacao): Observable<Transacao> {
    return this.http.post<Transacao>(
      this.apiUrlTransacaos,
      JSON.stringify(transacao),
      this.httpOptions
    );
  }

  buscarContaPorId(id: number): Observable<Conta> {
    return this.http.get<Conta>(this.apiUrlConta + '/' + id, this.httpOptions);
  }

  buscarContaPorUserId(id: number): Observable<Conta[]> {
    return this.http.get<Conta[]>(
      this.apiUrlConta + '/' + id,
      this.httpOptions
    );
  }

  atualizarContaCliente(cliente: Conta): Observable<Conta> {
    return this.http.put<Conta>(
      this.apiUrlConta + '/' + cliente.id,
      JSON.stringify(cliente),
      this.httpOptions
    );
  }

  getClientesByGerente(idGerente: number): Observable<Conta[]> {
    return this.http.get<Conta[]>(
      this.apiUrlConta + '/por-gerente/' + idGerente,
      this.httpOptions
    );
  }

  getClientesPendenteByGerente(idGerente: number): Observable<Conta[]> {
    window.alert("TOKEN PARA LIST " + localStorage[LS_TOKEN]);
    return this.http.get<Conta[]>(
      this.apiUrlConta + '/pendentes/' + idGerente,
      this.httpOptions
    );
  }
}
