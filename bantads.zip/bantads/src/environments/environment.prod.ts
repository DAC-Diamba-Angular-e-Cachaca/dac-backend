export const environment = {
  production: true,
  url: {
    auth: 'http://localhost:5010/auth',
    cliente: 'http://localhost:5010/cliente',
    conta: 'http://localhost:5010/conta',
    transacaos: 'http://localhost:5010/transacaos',
    gerente: 'http://localhost:5010/gerente',
    orquestrador: 'http://localhost:5010/orquestrador',
  },
};
